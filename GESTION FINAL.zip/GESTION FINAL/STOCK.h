#pragma once
#include <stdio.h>
#include <string.h>



// Function declarations
int authentifier(char fichiernom[], char nom_utilisateur[], char mot_de_passe[]);
void modifierProduit(const char fichier, char nomProduit);
void ajouterProduit(const char fichier);
void supprimerProduit(const char fichier, char nomProduit) ;

