#include <stdio.h>
#include <stdlib.h>
#include "STOCK.h"

void main()
{
    char mp[30], nom[50];
    int a, choix;
    char produitr[30];
    const char nomfichier[] = "utilisateur.csv";
    const char nomf2[] = "stock.csv";

    printf("Bienvenue dans le gestionnaire de stock \n");
    printf("-----------***********-----------\n");
    printf("entrer vos information :\n");
    printf("\n");
    printf("entre votre nom : ");
    scanf("%s", nom);
    getchar();
    printf("entre votre mot de passe : ");
    scanf("%s", mp);

    a = authentifier(nomfichier, nom, mp);
    if (a == 1)
    {
        printf("\n------------Menu------------\n");
        printf(" 1. Ajouter \n");
        printf(" 2. Modifier\n");
        printf(" 3. Supprimer\n");
        printf(" 4. Quitter\n");
        printf("\n");
        scanf("%d", &choix);

        switch (choix)
        {
            case 1:
                ajouterProduit(nomf2);
                break;
            case 2:
                printf("\n--- Donner le nom du produit que vous voulez modifier \n");
                scanf("%s", produitr);
                modifierProduit(nomf2, produitr);
                break;
            case 3:
                printf("\n--- Donner le nom du produit que vous voulez supprimer \n");
                scanf("%s", produitr);
                supprimerProduit(nomf2, produitr);
                break;
            case 4:
                break;
            default:
                printf("Choix invalide!\n");
        }
    }
    else
    {
        printf("Authentification echouee.\n");
    }
}
