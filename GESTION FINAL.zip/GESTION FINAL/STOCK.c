#include <stdio.h>
#include <string.h>
#include "stock.h"

typedef struct {
    int jour;
    int mois;
    int annee;
} Date;

typedef struct {
    char nom[100];
    char description[100];
    char nom_u[50];
    float prix;
    int quantite;
    Date date;
    Date date2;
    float seuil;
} produit;

int authentifier(char fichiernom[], char nom_utilisateur[], char mot_de_passe[]) {
    FILE* stock = fopen(fichiernom, "r");

    char ligne[100];
    char utilisateur[30];
    char mdp[20];

    while (fgets(ligne, sizeof(ligne), stock)) {
        ligne[strcspn(ligne, "\n")] = 0;  // n7aydo dil rj3a
        if (sscanf(ligne, "%[^:]:%s", utilisateur, mdp) == 2) {  // nakhdo nom u mot de passe
            if (strcmp(nom_utilisateur, utilisateur) == 0 && strcmp(mot_de_passe, mdp) == 0) {
                fclose(stock);
                return 1;  // rah kayn
            }
        }
    }

    fclose(stock);
    return 0;  // Authentification mkaynsh
}

// Fonction pour ajouter un produit
void ajouterProduit(const char fichier) {
    FILE* f = fopen(fichier, "a");
    produit p;

    printf("Donner les informations du produit :\n");
    scanf("%s %s %s %f %d %d/%d/%d %d/%d/%d %f", p.nom, p.description, p.nom_u, &p.prix, &p.quantite, &p.date.jour, &p.date.mois, &p.date.annee, &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil);
    fprintf(f, "%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n", p.nom, p.description, p.nom_u, p.prix, p.quantite, p.date.jour, p.date.mois, p.date.annee, p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);
    fclose(f);
}

// Fonction pour afficher la liste des produits
void afficherListeProduits(char fichier) {
    FILE* f = fopen(fichier, "r");
    produit p;

    while (fscanf(f, "%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
        p.nom, p.description, p.nom_u, &p.prix, &p.quantite, &p.date.jour, &p.date.mois, &p.date.annee, &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) != EOF) {
        printf("Nom: %s\n", p.nom);
        printf("Description: %s\n", p.description);
        printf("Utilisateur: %s\n", p.nom_u);
        printf("Prix: %.2f\n", p.prix);
        printf("Quantit�: %d\n", p.quantite);
        printf("Date d'entr�e: %d/%d/%d\n",  p.date.jour, p.date.mois, p.date.annee );
        printf("Date de sortie: %d/%d/%d\n", p.date2.jour, p.date2.mois, p.date2.annee);
        printf("Seuil: %.2f\n", p.seuil);
    }

    fclose(f);
}

// Fonction pour supprimer un produit
void supprimerProduit(const char fichier, char nomProduit) {
    FILE* f = fopen(fichier, "r");
    FILE* temp = fopen("temp.csv", "w");
    produit p;

    while (fscanf(f, "%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                  p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
               &p.date.jour, &p.date.mois, &p.date.annee, &p.date2.jour, &p.date2.mois, &p.date2.annee  , &p.seuil) != EOF) {
        if (strcmp(p.nom, nomProduit) != 0) {
            //kndkhlo ga3 haduk li mafihumsh hadik li 3tana
            fprintf(temp, "%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n",
                    p.nom, p.description, p.nom_u, p.prix, p.quantite,
                    p.date.jour, p.date.mois, p.date.annee,
                    p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);
        }
    }

    fclose(f);
    fclose(temp);

    remove(fichier);
    rename("temp.csv", fichier);
}

// Fonction pour modifier un produit
void modifierProduit(const char fichier, char nomProduit) {
    FILE* f = fopen(fichier, "r");
    FILE* temp = fopen("temp.csv", "w");
    produit p;

    while (fscanf(f, "%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                  p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
                  &p.date.jour, &p.date.mois, &p.date.annee, &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) != EOF) {
        if (strcmp(p.nom, nomProduit) == 0) {
            printf("entrez les nouvelles informations :\n");
            printf("Nom : ");
            scanf("%s", p.nom);
            printf("Description : ");
            scanf("%s", p.description);
            printf("Nom utilisateur : ");
            scanf("%s", p.nom_u);
            printf("Prix : ");
            scanf("%f", &p.prix);
            printf("Quantit� en stock : ");
            scanf("%d", &p.quantite);
            printf("Date d'entr�e (jour mois ann�e) : ");
            scanf("%d %d %d", &p.date.jour, &p.date.mois, &p.date.annee);
            printf("Date de sortie (jour mois ann�e) : ");
            scanf("%d %d %d", &p.date2.jour, &p.date2.mois, &p.date2.annee);
            printf("Seuil d'alerte : ");
            scanf("%f", &p.seuil);
        }

        fprintf(temp, "%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n",
                    p.nom, p.description, p.nom_u, p.prix, p.quantite,
                    p.date.jour, p.date.mois, p.date.annee,
                    p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);
    }

    fclose(f);
    fclose(temp);

    remove(fichier);
    rename("temp.csv", fichier);
}
